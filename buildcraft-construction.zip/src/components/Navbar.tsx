import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Hammer } from 'lucide-react';
import { Button } from './ui/Button';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const links = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Testimonials', path: '/testimonials' },
    { name: 'FAQ', path: '/faq' },
  ];

  const isHome = location.pathname === '/';
  const navBackground = scrolled || !isHome ? 'bg-white shadow-md py-4' : 'bg-transparent py-6';
  const logoTextClass = scrolled || !isHome ? 'text-primary-900' : 'text-white drop-shadow-md';
  const logoIconBg = scrolled || !isHome ? 'bg-primary-900 text-white' : 'bg-accent-500 text-primary-900';
  const linkClass = scrolled || !isHome ? 'text-primary-800' : 'text-white drop-shadow-md';
  const mobileBtnClass = scrolled || !isHome ? 'text-primary-900 hover:bg-gray-100' : 'text-white hover:bg-black/20';

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${navBackground}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className={`p-2 rounded transition-colors ${logoIconBg}`}>
              <Hammer size={24} className="group-hover:rotate-12 transition-transform" />
            </div>
            <span className={`font-serif text-2xl font-bold ${logoTextClass}`}>
              BuildCraft
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="flex space-x-6">
              {links.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`text-sm font-medium hover:text-accent-500 transition-colors ${linkClass}`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
            <Button to="/contact" variant={scrolled || !isHome ? 'primary' : 'secondary'} className="!py-2">
              Get a Quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 rounded-md ${mobileBtnClass}`}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t absolute w-full shadow-lg">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {links.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="block px-3 py-3 text-base font-medium text-primary-800 hover:text-accent-500 hover:bg-gray-50 border-b border-gray-100"
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-4">
              <Button to="/contact" className="w-full">
                Get a Quote
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
