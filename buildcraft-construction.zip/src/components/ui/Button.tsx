import { ReactNode } from 'react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
  to?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

export function Button({ children, variant = 'primary', className = '', to, onClick, type = 'button' }: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center px-6 py-3 font-medium transition-all duration-300 ease-out shadow-sm whitespace-nowrap';
  
  const variants = {
    primary: 'bg-primary-900 text-white hover:bg-accent-500 hover:shadow-md',
    secondary: 'bg-accent-500 text-primary-900 hover:bg-accent-600 hover:shadow-md',
    outline: 'border border-primary-900 text-primary-900 hover:bg-primary-900 hover:text-white',
  };

  const classes = `${baseStyles} ${variants[variant]} ${className}`;

  if (to) {
    return (
      <Link to={to} className={classes}>
        {children}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} className={classes}>
      {children}
    </button>
  );
}
