import { Link } from 'react-router-dom';
import { Hammer, Mail, Phone, MapPin, Instagram, Linkedin, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-primary-900 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center space-x-2 group inline-flex">
              <div className="p-2 rounded bg-accent-500 text-primary-900 transition-colors">
                <Hammer size={24} className="group-hover:rotate-12 transition-transform" />
              </div>
              <span className="font-serif text-2xl font-bold">
                BuildCraft
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Award-winning luxury construction and development. We build legacy properties that stand the test of time, blending masterful craftsmanship with modern innovation.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-400 hover:text-accent-500 transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-gray-400 hover:text-accent-500 transition-colors"><Linkedin size={20} /></a>
              <a href="#" className="text-gray-400 hover:text-accent-500 transition-colors"><Facebook size={20} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About', 'Services', 'Portfolio', 'Testimonials', 'FAQ'].map((item) => (
                <li key={item}>
                  <Link to={item === 'Home' ? '/' : `/${item.toLowerCase()}`} className="text-gray-400 hover:text-accent-500 transition-colors text-sm">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-6">Our Services</h4>
            <ul className="space-y-3">
              {['Custom Homes', 'Commercial Builds', 'Luxury Renovations', 'Architectural Design', 'Project Management'].map((item) => (
                <li key={item}>
                  <Link to="/services" className="text-gray-400 hover:text-accent-500 transition-colors text-sm">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-sm text-gray-400">
                <MapPin size={18} className="text-accent-500 shrink-0 mt-0.5" />
                <span>1200 Luxury Lane, Suite 400<br />Beverly Hills, CA 90210</span>
              </li>
              <li className="flex items-center space-x-3 text-sm text-gray-400">
                <Phone size={18} className="text-accent-500 shrink-0" />
                <a href="tel:+13105550199" className="hover:text-white transition-colors">+1 (310) 555-0199</a>
              </li>
              <li className="flex items-center space-x-3 text-sm text-gray-400">
                <Mail size={18} className="text-accent-500 shrink-0" />
                <a href="mailto:hello@buildcraft.com" className="hover:text-white transition-colors">hello@buildcraft.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} BuildCraft Construction. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm text-gray-500">
            <Link to="#" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="#" className="hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
