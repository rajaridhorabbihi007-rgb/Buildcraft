import { CheckCircle2 } from 'lucide-react';
import { SectionHeading } from '../components/ui/SectionHeading';

export default function About() {
  return (
    <div className="pt-24">
      {/* Header */}
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="About BuildCraft" subtitle="Our Story" centered className="!mb-0" />
        </div>
      </section>

      {/* Content */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1504307651254-35680f356f58?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Our team" 
                className="rounded-lg shadow-xl"
              />
            </div>
            <div>
              <h3 className="text-3xl font-serif text-primary-900 mb-6">Building Excellence Since 1998</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Founded on the principles of integrity, innovation, and unparalleled craftsmanship, BuildCraft Construction has established itself as the premier luxury builder in the region. We believe that every structure we create is a lasting legacy for our clients and the community.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Our team of master builders, award-winning architects, and dedicated project managers work in seamless harmony to transform complex visions into breathtaking realities.
              </p>
              <ul className="space-y-4 mb-8">
                {['Masterful Attention to Detail', 'Sustainable Building Practices', 'Transparent Client Communication', 'On-Time, On-Budget Delivery'].map((item, i) => (
                  <li key={i} className="flex items-center text-primary-800 font-medium">
                    <CheckCircle2 className="w-5 h-5 text-accent-500 mr-3" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
