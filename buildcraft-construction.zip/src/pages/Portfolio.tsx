import { SectionHeading } from '../components/ui/SectionHeading';

export default function Portfolio() {
  const projects = [
    { name: 'The Beverly Estate', category: 'Custom Home', img: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '12,000 sq ft' },
    { name: 'Aura Commercial Center', category: 'Commercial', img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '45,000 sq ft' },
    { name: 'Coastal Modern', category: 'Custom Home', img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '6,500 sq ft' },
    { name: 'Historic Renovation', category: 'Renovation', img: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '4,200 sq ft' },
    { name: 'Lumina Tech Hub', category: 'Commercial', img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '85,000 sq ft' },
    { name: 'The Glass Pavilion', category: 'Custom Home', img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', size: '8,900 sq ft' }
  ];

  return (
    <div className="pt-24">
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="Our Masterpieces" subtitle="Portfolio" centered className="!mb-0" />
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, i) => (
              <div key={i} className="group cursor-pointer">
                <div className="relative h-96 rounded-lg overflow-hidden mb-6">
                  <div className="absolute inset-0 bg-primary-900/60 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex flex-col items-center justify-center">
                    <span className="text-white font-serif text-2xl font-bold mb-2">{project.name}</span>
                    <span className="text-accent-500 font-medium tracking-wider uppercase text-sm mb-4">{project.category}</span>
                    <span className="text-white px-6 py-2 border border-white rounded-full hover:bg-white hover:text-primary-900 transition-colors">
                      View Gallery
                    </span>
                  </div>
                  <img src={project.img} alt={project.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-serif text-primary-900">{project.name}</h3>
                    <div className="text-sm text-gray-500 mt-1">{project.category}</div>
                  </div>
                  <div className="text-sm font-medium text-accent-600 bg-accent-500/10 px-3 py-1 rounded">
                    {project.size}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
