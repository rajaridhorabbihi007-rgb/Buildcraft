import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Button } from '../components/ui/Button';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What is your typical project timeline?",
      answer: "Timelines vary significantly based on project scope. A custom luxury home typically takes 12-18 months from design to completion. Major renovations may take 6-12 months. During our initial consultation, we provide a detailed timeline specific to your project."
    },
    {
      question: "Do you offer design-build services?",
      answer: "Yes, we strongly recommend our design-build approach. We have in-house designers and exclusive partnerships with elite architects. This ensures seamless communication between the design and construction phases, reducing costs and accelerating timelines."
    },
    {
      question: "Are you fully licensed, bonded, and insured?",
      answer: "Absolutely. BuildCraft holds the highest level of general contracting licenses in our operating states. We carry comprehensive liability insurance, workers' compensation, and bonding well above industry standards to protect your investment."
    },
    {
      question: "How do you handle change orders during construction?",
      answer: "We use a fully transparent, digital change order process. If you decide to modify the scope or materials, we present a detailed breakdown of the cost and timeline impact. No work proceeds on a change without your explicit written approval."
    },
    {
      question: "What kind of warranty do you provide on your work?",
      answer: "We stand behind our craftsmanship. We provide a comprehensive 1-year bumper-to-bumper warranty on all work, a 2-year warranty on mechanical, electrical, and plumbing systems, and a 10-year structural warranty on new builds."
    },
    {
      question: "Who will be managing my project on-site?",
      answer: "Every project is assigned a dedicated Project Manager and a full-time, on-site Superintendent. They ensure quality control, manage subcontractors, and act as your direct point of contact throughout the entire build process."
    }
  ];

  return (
    <div className="pt-24">
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="Frequently Asked Questions" subtitle="Knowledge Base" centered className="!mb-0" />
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-4 mb-16">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm transition-all duration-200"
              >
                <button
                  className="w-full px-6 py-5 text-left flex justify-between items-center focus:outline-none"
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                >
                  <span className="font-serif text-xl font-medium text-primary-900 pr-8">{faq.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-accent-500 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 shrink-0" />
                  )}
                </button>
                <div 
                  className={`px-6 overflow-hidden transition-all duration-300 ease-in-out ${
                    openIndex === index ? 'max-h-96 pb-6 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <p className="text-gray-600 leading-relaxed pt-2 border-t border-gray-100">
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center bg-surface-50 p-10 rounded-xl">
            <h3 className="font-serif text-2xl text-primary-900 mb-4">Still have questions?</h3>
            <p className="text-gray-600 mb-6">Our team is ready to provide the answers you need to make an informed decision.</p>
            <Button to="/contact" variant="primary">Contact Our Team</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
