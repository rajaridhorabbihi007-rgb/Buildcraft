import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Star, Trophy, Users, Building, Shield } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="w-full">
      {/* 1. Premium Hero Section */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80" 
            alt="Luxury modern home exterior" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary-900/60 mix-blend-multiply" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="inline-block text-accent-500 font-semibold tracking-widest uppercase text-sm mb-6">
              Award-Winning Luxury Construction
            </span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white font-bold mb-6 leading-tight max-w-4xl mx-auto drop-shadow-lg">
              Building Legacy <br/><span className="text-accent-500 font-normal italic">Properties</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl mx-auto leading-relaxed drop-shadow">
              We transform ambitious visions into breathtaking realities. Exceptional craftsmanship for homeowners, investors, and commercial developers.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Button to="/contact" variant="secondary" className="w-full sm:w-auto text-lg px-8 py-4">
                Discuss Your Project
              </Button>
              <Button to="/portfolio" variant="outline" className="w-full sm:w-auto text-lg px-8 py-4 !border-white !text-white hover:!bg-white hover:!text-primary-900">
                View Our Portfolio
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2. Social Proof / Logos */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm font-semibold text-gray-400 uppercase tracking-wider mb-8">
            Trusted by industry leaders & featured in
          </p>
          <div className="flex flex-wrap justify-center items-center gap-10 md:gap-20 opacity-60 grayscale">
            {/* Placeholder logos using text for now */}
            <span className="font-serif text-2xl font-bold text-gray-800">Architectural Digest</span>
            <span className="font-serif text-2xl font-bold text-gray-800">Forbes</span>
            <span className="font-serif text-2xl font-bold text-gray-800">Dwell</span>
            <span className="font-serif text-2xl font-bold text-gray-800">Vogue Living</span>
          </div>
        </div>
      </section>

      {/* 3. Company Statistics */}
      <section className="py-20 bg-surface-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-gray-200">
            {[
              { label: 'Years Experience', value: '25+' },
              { label: 'Projects Completed', value: '150+' },
              { label: 'Industry Awards', value: '42' },
              { label: 'Client Satisfaction', value: '100%' }
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center px-4"
              >
                <div className="text-4xl md:text-5xl font-serif text-primary-900 mb-2">{stat.value}</div>
                <div className="text-sm text-gray-500 font-medium uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Services */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="Masterful Craftsmanship Across Domains" 
            subtitle="Our Expertise"
            centered
          />
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {[
              {
                title: 'Custom Luxury Homes',
                desc: 'Bespoke residences designed and built to reflect your unique lifestyle and sophisticated taste.',
                icon: Building,
                img: 'https://images.unsplash.com/photo-1613490908571-9b3de5fb442b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
              },
              {
                title: 'Commercial Development',
                desc: 'High-end commercial spaces that elevate your brand and provide exceptional environments.',
                icon: Users,
                img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
              },
              {
                title: 'Premium Renovations',
                desc: 'Transforming existing properties into modern masterpieces with seamless architectural integration.',
                icon: Trophy,
                img: 'https://images.unsplash.com/photo-1505843513577-22bb7d21e455?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
              }
            ].map((srv, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="group relative bg-surface-50 rounded-lg overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="h-64 overflow-hidden relative">
                  <div className="absolute inset-0 bg-primary-900/20 group-hover:bg-transparent transition-colors z-10" />
                  <img src={srv.img} alt={srv.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="p-8">
                  <srv.icon className="text-accent-500 w-10 h-10 mb-4" />
                  <h3 className="text-2xl font-serif text-primary-900 mb-3">{srv.title}</h3>
                  <p className="text-gray-600 mb-6 line-clamp-3">{srv.desc}</p>
                  <Link to="/services" className="inline-flex items-center text-sm font-semibold text-primary-900 group-hover:text-accent-500 transition-colors">
                    Learn more <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Why Choose Us (Trust Signals) */}
      <section className="py-24 bg-primary-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <SectionHeading 
                title="The BuildCraft Distinction" 
                subtitle="Why Choose Us"
                className="!mb-8 text-white [&>h2]:text-white"
              />
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                We don't just build structures; we build trust. Our commitment to excellence, transparency, and precision sets us apart in the luxury construction landscape.
              </p>
              <ul className="space-y-6">
                {[
                  'Uncompromising Quality & Materials',
                  'Transparent Process & Pricing',
                  'Dedicated Project Management',
                  'Award-Winning Architectural Partners'
                ].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle2 className="text-accent-500 w-6 h-6 mr-4 shrink-0 mt-0.5" />
                    <span className="text-lg font-medium text-gray-100">{item}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-12">
                <Button to="/about" variant="secondary">
                  Discover Our Story
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-accent-500/10 rounded-lg transform rotate-3" />
              <img 
                src="https://images.unsplash.com/photo-1541888081198-5c421731665a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Construction planning" 
                className="relative rounded-lg shadow-2xl object-cover h-[500px] w-full"
              />
              <div className="absolute -bottom-8 -left-8 bg-white text-primary-900 p-6 rounded-lg shadow-xl max-w-xs hidden md:block">
                <Shield className="w-10 h-10 text-accent-500 mb-3" />
                <h4 className="font-serif font-bold text-lg mb-1">Fully Licensed & Insured</h4>
                <p className="text-sm text-gray-500">Complete peace of mind for your most valuable asset.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Portfolio Preview */}
      <section className="py-24 bg-surface-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <SectionHeading 
              title="Recent Masterpieces" 
              subtitle="Our Portfolio"
              className="!mb-0"
            />
            <Link to="/portfolio" className="hidden md:inline-flex items-center text-primary-900 font-semibold hover:text-accent-500 transition-colors">
              View All Projects <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: 'The Beverly Estate', category: 'Custom Home', img: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
              { name: 'Aura Commercial', category: 'Commercial', img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
              { name: 'Coastal Modern', category: 'Renovation', img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' }
            ].map((project, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="group cursor-pointer"
              >
                <div className="relative h-80 rounded-lg overflow-hidden mb-4">
                  <div className="absolute inset-0 bg-primary-900/40 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center justify-center">
                    <span className="text-white font-medium px-6 py-2 border border-white rounded-full backdrop-blur-sm">View Project</span>
                  </div>
                  <img src={project.img} alt={project.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="text-sm text-accent-500 font-semibold uppercase tracking-wider mb-1">{project.category}</div>
                <h3 className="text-2xl font-serif text-primary-900">{project.name}</h3>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 text-center md:hidden">
            <Button to="/portfolio" variant="outline">View All Projects</Button>
          </div>
        </div>
      </section>

      {/* 7. Testimonials */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="What Our Clients Say" 
            subtitle="Testimonials"
            centered
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
            {[
              {
                text: "BuildCraft exceeded our expectations at every turn. Their attention to detail and commitment to our vision created a home we will cherish for generations.",
                author: "Sarah & James T.",
                role: "Homeowners, The Beverly Estate"
              },
              {
                text: "As a property investor, time and budget are critical. BuildCraft delivered our commercial project ahead of schedule without compromising a single detail.",
                author: "Michael R.",
                role: "CEO, Horizon Developments"
              },
              {
                text: "The level of professionalism and craftsmanship is unmatched. They turned a stressful renovation process into a seamless, enjoyable experience.",
                author: "Elena C.",
                role: "Homeowner, Coastal Modern"
              }
            ].map((testimonial, i) => (
              <div key={i} className="bg-surface-50 p-8 rounded-lg shadow-sm relative">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 text-accent-500 fill-current" />)}
                </div>
                <p className="text-gray-700 italic mb-6">"{testimonial.text}"</p>
                <div>
                  <div className="font-serif font-bold text-primary-900">{testimonial.author}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. Final Call To Action */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary-900">
          <img 
            src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
            alt="Architecture abstract" 
            className="w-full h-full object-cover opacity-20 mix-blend-luminosity"
          />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-6">Ready to Build Your Legacy?</h2>
          <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
            Schedule a confidential consultation with our architectural and construction experts to discuss your vision.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Button to="/contact" variant="secondary" className="text-lg px-8 py-4">
              Request a Consultation
            </Button>
            <Button to="tel:+13105550199" variant="outline" className="text-lg px-8 py-4 !border-white !text-white hover:!bg-white hover:!text-primary-900">
              Call Us Now
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
