import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send } from 'lucide-react';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Button } from '../components/ui/Button';

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <div className="pt-24">
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="Start Your Project" subtitle="Contact Us" centered className="!mb-0" />
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            
            {/* Contact Information */}
            <div>
              <h3 className="text-3xl font-serif text-primary-900 mb-6">Let's Discuss Your Vision</h3>
              <p className="text-gray-600 mb-12 leading-relaxed text-lg">
                Whether you have complete architectural plans or just a concept in mind, our team is ready to help bring your luxury project to life. Connect with our executive team for a confidential consultation.
              </p>

              <div className="space-y-8">
                <div className="flex items-start">
                  <div className="bg-accent-500/10 p-4 rounded-full mr-6">
                    <MapPin className="w-6 h-6 text-accent-600" />
                  </div>
                  <div>
                    <h4 className="font-serif text-xl font-bold text-primary-900 mb-2">Corporate Headquarters</h4>
                    <p className="text-gray-600">1200 Luxury Lane, Suite 400<br />Beverly Hills, CA 90210</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-accent-500/10 p-4 rounded-full mr-6">
                    <Phone className="w-6 h-6 text-accent-600" />
                  </div>
                  <div>
                    <h4 className="font-serif text-xl font-bold text-primary-900 mb-2">Direct Phone</h4>
                    <a href="tel:+13105550199" className="text-gray-600 hover:text-accent-600 transition-colors">
                      +1 (310) 555-0199
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-accent-500/10 p-4 rounded-full mr-6">
                    <Mail className="w-6 h-6 text-accent-600" />
                  </div>
                  <div>
                    <h4 className="font-serif text-xl font-bold text-primary-900 mb-2">Email Inquiries</h4>
                    <a href="mailto:hello@buildcraft.com" className="text-gray-600 hover:text-accent-600 transition-colors">
                      hello@buildcraft.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
              {isSuccess ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4">
                    <Send className="w-8 h-8" />
                  </div>
                  <h3 className="text-3xl font-serif text-primary-900">Request Sent</h3>
                  <p className="text-gray-600">
                    Thank you for reaching out. A senior member of our team will contact you within 24 business hours to schedule your consultation.
                  </p>
                  <Button onClick={() => setIsSuccess(false)} variant="outline" className="mt-6">
                    Send Another Message
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input required type="text" id="firstName" className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors" placeholder="John" />
                    </div>
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input required type="text" id="lastName" className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors" placeholder="Doe" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <input required type="email" id="email" className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors" placeholder="john@example.com" />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <input required type="tel" id="phone" className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors" placeholder="(555) 123-4567" />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="projectType" className="block text-sm font-medium text-gray-700 mb-2">Project Type</label>
                    <select id="projectType" className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors bg-white">
                      <option>Custom Luxury Home</option>
                      <option>Commercial Development</option>
                      <option>Premium Renovation</option>
                      <option>Architectural Design</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Project Details</label>
                    <textarea required id="message" rows={5} className="w-full px-4 py-3 rounded border border-gray-300 focus:border-accent-500 focus:ring-1 focus:ring-accent-500 outline-none transition-colors resize-none" placeholder="Please describe your vision, location, and ideal timeline..."></textarea>
                  </div>

                  <Button type="submit" className="w-full" variant="primary">
                    {isSubmitting ? 'Sending...' : 'Submit Request'}
                  </Button>
                  <p className="text-xs text-gray-400 text-center mt-4">
                    Your information is kept strictly confidential.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
