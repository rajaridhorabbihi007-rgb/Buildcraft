import { Star } from 'lucide-react';
import { SectionHeading } from '../components/ui/SectionHeading';

export default function Testimonials() {
  const testimonials = [
    {
      text: "BuildCraft exceeded our expectations at every turn. Their attention to detail and commitment to our vision created a home we will cherish for generations.",
      author: "Sarah & James T.",
      role: "Homeowners, The Beverly Estate"
    },
    {
      text: "As a property investor, time and budget are critical. BuildCraft delivered our commercial project ahead of schedule without compromising a single detail. Truly exceptional.",
      author: "Michael R.",
      role: "CEO, Horizon Developments"
    },
    {
      text: "The level of professionalism and craftsmanship is unmatched. They turned a stressful renovation process into a seamless, enjoyable experience. The site was always spotless.",
      author: "Elena C.",
      role: "Homeowner, Coastal Modern"
    },
    {
      text: "Their in-house architectural partners understood exactly what we wanted. The transition from design to build was incredibly smooth. We felt heard and valued throughout.",
      author: "David L.",
      role: "Homeowner, The Glass Pavilion"
    },
    {
      text: "Our corporate headquarters needed a total overhaul while remaining operational. BuildCraft managed the phased construction perfectly. The final result elevated our entire company culture.",
      author: "Jessica W.",
      role: "Operations Director, Lumina Tech"
    },
    {
      text: "You pay for premium, and you get absolute perfection. Their finish carpentry and masonry work are museum-quality. I wouldn't trust anyone else with my properties.",
      author: "Robert K.",
      role: "Real Estate Developer"
    }
  ];

  return (
    <div className="pt-24">
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="Client Success Stories" subtitle="Testimonials" centered className="!mb-0" />
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, i) => (
              <div key={i} className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 relative">
                <div className="flex mb-6">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 text-accent-500 fill-current" />)}
                </div>
                <p className="text-gray-700 italic mb-8 leading-relaxed">"{testimonial.text}"</p>
                <div className="mt-auto">
                  <div className="font-serif font-bold text-primary-900 text-lg">{testimonial.author}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
