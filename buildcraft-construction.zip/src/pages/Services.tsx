import { Building, Home as HomeIcon, Layout, PenTool, Shield, Users } from 'lucide-react';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Button } from '../components/ui/Button';

export default function Services() {
  const services = [
    {
      icon: HomeIcon,
      title: 'Custom Luxury Homes',
      desc: 'From architectural conception to the final interior details, we build bespoke estates that reflect your vision and lifestyle. We handle permitting, zoning, and construction with white-glove service.'
    },
    {
      icon: Building,
      title: 'Commercial Development',
      desc: 'High-performance commercial spaces, boutique retail, and hospitality builds designed to elevate your brand presence and optimize operational efficiency.'
    },
    {
      icon: PenTool,
      title: 'Premium Renovations',
      desc: 'Whole-home remodels and historic restorations that seamlessly blend modern amenities with classic architectural integrity.'
    },
    {
      icon: Layout,
      title: 'Architectural Design',
      desc: 'In-house design-build services partnering with elite architects to ensure your vision is executable, cost-effective, and aesthetically flawless.'
    },
    {
      icon: Users,
      title: 'Project Management',
      desc: 'Dedicated project managers utilize advanced scheduling and transparent reporting to keep your build on track, keeping you informed at every milestone.'
    },
    {
      icon: Shield,
      title: 'Estate Maintenance',
      desc: 'Post-construction care and maintenance programs to ensure your luxury property remains in pristine condition for generations.'
    }
  ];

  return (
    <div className="pt-24">
      <section className="bg-surface-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionHeading title="Our Services" subtitle="What We Do" centered className="!mb-0" />
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((srv, i) => (
              <div key={i} className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 hover:shadow-lg transition-shadow">
                <srv.icon className="w-12 h-12 text-accent-500 mb-6" />
                <h3 className="text-2xl font-serif text-primary-900 mb-4">{srv.title}</h3>
                <p className="text-gray-600 leading-relaxed">{srv.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-20 text-center bg-primary-900 text-white p-12 rounded-2xl">
            <h3 className="text-3xl font-serif mb-4">Have a unique project in mind?</h3>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">Our design-build team specializes in solving complex architectural challenges. Let's discuss your vision.</p>
            <Button to="/contact" variant="secondary">Request a Consultation</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
